package Test;

import Base.BaseTest;
import Pages.DalamationPage;
import Pages.PetStoreMainMenu;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PetStoreTest extends BaseTest {

    @BeforeMethod
    public void pageSetUp(){
        driver.navigate().to("https://petstore.octoperf.com/actions/Catalog.action");
    }
    @Test
    public void test1(){
        petStoreMainMenu.clickOnDogsIcon();
        dogsPage.clickOnTheDalmation();
        dalamationPage.clickOnDalmationMale();
        dalmationMalePage.clickOnAddToCartButton();
        shopingCartPage.clickOnReturnToMainMenuButton();
        petStoreMainMenu.clickOnShopCartButton();
        Assert.assertEquals(shopingCartPage.getAttributeFromTextbox(),"1");
        Assert.assertTrue(shopingCartPage.getDescriptionNameMaleDalmation().isDisplayed());
        Assert.assertEquals(shopingCartPage.getDescriptionNameMaleDalmation().getText(),"Spotless Male Puppy Dalmation");
    }
}
